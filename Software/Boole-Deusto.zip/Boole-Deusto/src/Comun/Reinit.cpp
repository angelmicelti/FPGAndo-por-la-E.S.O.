//---------------------------------------------------------------------------


#pragma hdrstop

#include "Reinit.hpp"

//---------------------------------------------------------------------------

#pragma package(smart_init)

namespace Reinit
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE int __fastcall LoadNewResourceModule(unsigned Locale)
{
}
extern PACKAGE void __fastcall ReinitializeForms(void)
{
}

}	/* namespace Reinit */

