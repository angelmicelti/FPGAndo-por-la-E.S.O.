//---------------------------------------------------------------------------

#ifndef VKLazoH
#define VKLazoH
#include <utility>
using namespace std;
//---------------------------------------------------------------------------

class Lazo
{

public:
	pair<int,int> comienzoLazo;
	pair<int,int> finLazo;
        int tamanyoX;
        int tamanyoY;

        bool saleX, saleY;
};

#endif
