#ifndef reductioH
#define reductioH


#define NUM_METODOS_OBT 1

#define QM 0


#define NUM_METODOS_SEL 6

#define QM_NOHEUR_SESGADO1 0
#define QM_NOHEUR_SESGADO2 1
#define QM_NOHEUR_NOSESGADO 2
#define QM_HEUR_BESTCOVER 3
#define QM_HEUR_ALEATORIO 4
#define FUERZA_BRUTA 5


#define PRIMARIO 0
#define SECUNDARIO 1
#define NO_ESENCIAL 2



#endif
