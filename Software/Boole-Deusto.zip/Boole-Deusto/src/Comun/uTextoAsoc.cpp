//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "uTextoAsoc.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfTextoAsoc *fTextoAsoc;
//---------------------------------------------------------------------------
__fastcall TfTextoAsoc::TfTextoAsoc(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
