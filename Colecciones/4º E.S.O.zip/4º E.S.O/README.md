# 4º E.S.O. Collection

[![Icestudio](https://img.shields.io/badge/collection-icestudio-blue.svg)](https://github.com/FPGAwars/icestudio)
![Version](https://img.shields.io/badge/version-v1.0.0-orange.svg)

Componentes necesarios para 4º de E.S.O..

## Install

* Download the collection
* Install the collection: *Tools > Collections > Add*
* Load the collection: *Select > Collection*

## Blocks
* *Bits*
  * *0*
    * 0-antorcha
    * 0-fuego
    * 0-ies
    * 0-number
    * 0-patasAzul
    * 0-patasNegro
    * 0-patasRojo
    * 0-patasVerde
    * 0-switch
  * *1*
    * 1-antorcha
    * 1-fuego
    * 1-ies
    * 1-number
    * 1-patasAzul
    * 1-patasNegro
    * 1-patasRojo
    * 1-patasVerde
    * 1-switch
* *Circuitos*
  * problema42
  * problema43
* *Puertas*
  * *1 bit*
    * NOT
  * *2 bit*
    * AND
    * NAND
    * NOR
    * OR
    * XNOR
    * XOR
  * *3 bit*
    * AND
    * NAND
    * NOR
    * OR
  * *4 bit*
    * AND
    * NAND
    * NOR
    * OR
* *Varios*
  * *Biestables*
    * *01-Biestable-D*
      * 01-Biestable-D-generic
      * 02-Biestable-D-0
      * 03-Biestable-D-1
      * 04-Biestable-D-ena-generic
      * 05-Biestable-D-ena-0
      * 06-Biestable-D-ena-1
      * 07-Biestable-D-rst-generic
      * 08-Biestable-D-rst-0
      * 09-Biestable-D-rst-1
      * 10-Biestable-D-rst-ena-generic
      * 11-Biestable-D-rst-ena-0
      * 12-Biestable-D-rst-ena-1
      * 13-Biestable-D-set-rst-generic
      * 14-Biestable-D-set-rst-0
      * 15-Biestable-D-set-rst-1
    * *02-Flip-flop-D*
      * Flip-flop-D-0
      * Flip-flop-D-1
      * Flip-flop-D-parametric
    * *03-Chincheta-D*
      * Chincheta-D-0-set-rst
      * Chincheta-D-0
      * Chincheta-D-1
    * *04-Biestable-T*
      * 01-Biestable-T-generic
      * 02-Biestable-T-0
      * 03-Biestable-T-1
      * 04-Biestable-T-sync-ini
      * 05-Biestable-T-sync-0
      * 06-Biestable-T-sync-1
      * Biestable-T-sync-0-verilog
    * *05-Chincheta-T*
      * Chincheta-T-0
      * Chincheta-T-1
  * *Bombeo*
    * Corazon_10Hz
    * Corazon_10usec_P-ena
    * Corazon_1Hz
    * Corazon_1Hz_P
    * Corazon_1x_P
    * Corazon_1x_P_ena
    * Corazon_20ms_P-ena
    * Corazon_2Hz
    * Corazon_2Hz_P
    * Corazon_3Hz
    * Corazon_400Hz_P-ena
    * Corazon_4Hz
    * Corazon_5Hz
    * Corazon_7Hz
    * Corazon_x1
    * Corazon_x4
    * Corazon_xHz
    * Corazon_xmsec
  * *Buses*
    * *02_bits*
      * Join-2
      * Split-2
    * *03_bits*
      * Join-2-1
      * Join-3
      * Split-2-1
      * Split-3
    * *04_bits*
      * Join-2
      * Join-4
      * Split-2
      * Split-4
    * *07_bits*
      * Join-4-3
      * Split-4-3
    * *08_bits*
      * Join-2
      * Join-7-1
      * Split-2
    * *16_bits*
      * Join-2
      * Split-2
    * *23_bits*
      * 01-Split-16-7
      * 02-Join-16-7
      * Split-7-16
    * *24_bits*
      * Join3
      * Split3-8
  * *Decoder*
    * *Bin to 7seg*
      * Decoder_BCD_7Seg(7447)
      * Decoder_Bin-7SegAC-verilog
      * Decoder_Bin-7SegCC-verilog
  * *Musica*
    * Beep1
    * Beep2
    * notas
  * *PWM_LED*
    * pwm-led-X1
    * pwm-led-X2
    * pwm-led-X3
    * pwm-led-ramp
    * pwm-ramp
  * *Pulsadores*
    * Antirrebotes
    * Pull-up
    * Pulsador-Pulso
    * Pulsador_cambio
  * *Servos*
    * MotorBit-Custom
    * MotorBit
    * ServoBit-180
    * ServoBit-90
    * ServoBit
    * ServoTime
    * *Futaba-3003*
      * ServoBit180-Futaba3003
      * ServoBit90-Futaba3003
  * *Signals*
    * Pulso
  * *Stickers*
    * Alhambrabits
    * GNU-Linux
    * IESVDV
    * Patrimonio_tecnologico_humanidad
    * Smiley
    * Trollface
    * Yao-Ming
    * caca
    * fpgawars
    * icestudio
    * like
    * openhardware
  * *Timers*
    * Timer-10xusecs-8bits
    * Timer-secs
    * Timer_1,4seg
  * *Varios*
    * Tortuga
    * Tri-state

## Examples
* *Boletin 4*
  * Ej41
  * Ej42
  * Ej42Bloque
  * Ej43
  * Ej43B
  * Ej44
  * Ej44Bloque
  * Ej45
  * Ej45B
  * Ej46
  * Ej47
* *Boletin 5*
  * Ej51
  * Ej52
  * Ej53
  * Ej54
* *Boletin 6*
* *Boletin 7*
* *Boletin 8*
* *Ejemplos 1*
  * 01_ledon
  * 02-ledson
  * 03-blink
  * 04-blink-not
  * 05-external-leds
  * 06-Servobit-1
  * 07-divisor2
  * 08-beep
  * 09-sirena
  * 10-pulsador-beep
  * 11-alarma
  * leds-off
* *Ejemplos 2*
  * *01-Basicos*
    * 01-led-on
    * 02-led-off
    * 03-Dos-leds-encendidos
    * 04-Leds-impares-encendidos
  * *02-Bloques-personalizados*
    * 01-Comentarios
    * 02-Comentarios-Leds-impares-encendidos
    * 03-Constantes-bit-personalizadas
    * 04-Antorcha-encendiendo-dos-leds
    * 05-mi-bit-1-ejemplo
  * *02-Pulsadores*
    * 01-Boton-led
    * 02-Dos-botones-leds
    * 03-Botones-con-memoria
  * *03-Basicos-II*
    * 04-Led-parpadeante
    * 05-Leds-parpadeantes-diferentes-velocidades
    * 06-Leds-parpadeando-a-la-vez
    * 07-Leds-alternantes
  * *03-Temporizadores*
    * 01-Led-on-5seg
  * *04-Servos*
    * 01-Futaba-3003-90-grados-MONOCULO
    * 02-Ajustes-Servobit
    * 03-Barrera-con-boton-manual
    * 04-Barrera-con-apertura-manual-temporizada
    * 05-Barrera-con-apertura-IR-temporizada
    * 06-Barrera-con-apertura-IR-cierre-IR
    * 07-Perrito-contento
    * 08-Secuencia-Servo-ROM
    * 09-Servo-Serial-DTR
    * 10-Serial-Servo-data
  * *Test*
    * Contador-8
    * ServoBit
    * ServoBit180-Futaba3003-test
    * ServoBit90-Futaba3003-test
    * Servotime-01
    * Timer-10xmicro-secs-test
* *Ejemplos 3*
  * 01_ledon
  * 02-ledson
  * 03-blink
  * 04-blink-not
  * 05-external-leds
  * 06-Servobit-1
  * 07-divisor2
  * 08-beep
  * 09-sirena
  * 10-pulsador-beep
  * 11-alarma
  * leds-off


## Authors
* [Ángel Millán León](https://github.com/angelmicelti)


## License

Licensed under [GPL-2.0](https://opensource.org/licenses/GPL-2.0).
